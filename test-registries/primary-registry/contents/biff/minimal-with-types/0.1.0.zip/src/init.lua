local _test = ` \
    test {1337} \
    \' \
export type SHOULD_NOT_BE_FORWARDED = number \
	export type SHOULD_NOT_BE_FORWARDED = number \
	--[[ \
`;export type A = number

local _normalString = " \
\" \
export type SHOULD_NOT_BE_FORWARDED = number \
";export type B = number

local _longString = [[
export type SHOULD_NOT_BE_FORWARDED = number \
	export type SHOULD_NOT_BE_FORWARDED = number \
]];export type C = number

local _testLongStringEnded = [=[ test ]==]
export type SHOULD_NOT_BE_FORWARDED = number
]=];export type D = number

----[[

--[[]];export type E = number

--[=[
export type SHOULD_NOT_BE_FORWARDED = number
--]]

export type SHOULD_NOT_BE_FORWARDED = number
--]=];export type F = number

type SHOULD_NOT_BE_FORWARDED = number
export type BadDefaultTypeParam<T = SHOULD_NOT_BE_FORWARDED> = number

export type WithTypeParams<T, U> = {
    a: T,
    b: U,
}

export type WithParamPack<T...> = number

return {}